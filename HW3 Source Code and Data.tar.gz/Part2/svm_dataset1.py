import pickle
import numpy as np


dataset, labels = pickle.load(open("../datasets/part2_dataset_1.data", "rb"))
