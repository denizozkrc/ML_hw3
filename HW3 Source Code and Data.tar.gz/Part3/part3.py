import pickle

dataset, labels = pickle.load(open("../datasets/part3_dataset.data", "rb"))

